package Assignment;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class StartExam
 */
@WebServlet("/StartExam")
public class StartExam extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StartExam() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    Map<Integer,String> Answers;
    
    public void init(ServletConfig config) throws ServletException{
    	super.init(config);
    	Answers=new HashMap<>();
    	Answers.put(1,"Tiger");
    	Answers.put(2,"4");
    	Answers.put(3,"Charles Babbage");
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		HttpSession session = request.getSession();
        session.setAttribute("examStartTime", System.currentTimeMillis());

        response.sendRedirect("question1");
        
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		doGet(request, response);
		

		String uname = request.getParameter("uname");
        String regNo = request.getParameter("regNo");

        
		if (uname != null && regNo != null) {
            HttpSession session = request.getSession(true);
            session.setAttribute("uname", uname);
            session.setAttribute("regNo", regNo);
            session.setAttribute("examStartTime", System.currentTimeMillis());

            // Start the exam
            response.sendRedirect("question1");
            return;
        }

		
		HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("examStartTime") == null) {
            response.sendRedirect("StartExam");
            return;
        }
        
        
        Map<Integer,String> Result = new HashMap<>();
        int marks = 0;
        
        for(Map.Entry<Integer,String> ent:Answers.entrySet()) {
        	String ans = (String)session.getAttribute("q"+ent.getKey());
        	if(ans!=null && ans.equals(Answers.get(ent.getKey()))) {
        		marks+=1;
        	}
        	Result.put(ent.getKey(), ans);
        }
        
        
        String encodedMarks = URLEncoder.encode(String.valueOf(marks), StandardCharsets.UTF_8.toString());
        String encodedResults = URLEncoder.encode(String.valueOf(Result), StandardCharsets.UTF_8.toString());
		response.sendRedirect("examOver.html?marks="+encodedMarks+"&results="+encodedResults);
		
       
        
	}

}
