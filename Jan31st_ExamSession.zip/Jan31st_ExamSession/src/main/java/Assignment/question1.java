package Assignment;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class question1
 */
@WebServlet("/question1")
public class question1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	
	private static final long EXAM_TIME = 5 * 60 * 1000;
	
	
    public question1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
//		response.setContentType("text/html");
//		PrintWriter o=response.getWriter();
		
		HttpSession s1 = request.getSession();
		s1.setMaxInactiveInterval(60);
		

		
		response.sendRedirect("question1.html");
//		RequestDispatcher ch = request.getRequestDispatcher()
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		
		


		HttpSession session = request.getSession(false);
		if (session == null || session.getAttribute("examStartTime") == null) {
            response.sendRedirect("login.html");
            return;
        }

        long startTime = (long) session.getAttribute("examStartTime");
        long currentTime = System.currentTimeMillis();

        if (currentTime - startTime > EXAM_TIME) {
            session.invalidate();
            response.sendRedirect("examOver.html");
            return;
        }

        String ans1 = request.getParameter("ans1");
        session.setAttribute("q1", ans1);
        
        response.sendRedirect("question2");
	}

}
