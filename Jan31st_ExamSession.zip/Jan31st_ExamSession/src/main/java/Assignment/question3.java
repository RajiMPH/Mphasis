package Assignment;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class question3
 */
@WebServlet("/question3")
public class question3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public question3() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    private static final long EXAM_TIME = 5 * 60 * 1000;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		HttpSession s1 = request.getSession();
		s1.setMaxInactiveInterval(60);
		

		
		response.sendRedirect("question3.html");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		doGet(request, response);
		
		HttpSession session = request.getSession(false);

		if (session == null || session.getAttribute("examStartTime") == null) {
            response.sendRedirect("login.html");
            return;
        }


        long startTime = (long) session.getAttribute("examStartTime");
        long currentTime = System.currentTimeMillis();

        if (currentTime - startTime > EXAM_TIME) {
            session.invalidate();
            response.sendRedirect("examOver.html");
            return;
        }

        String ans3 = request.getParameter("ans3");
        session.setAttribute("q3", ans3);
        
        request.getRequestDispatcher("/StartExam").forward(request, response);
	}

}
