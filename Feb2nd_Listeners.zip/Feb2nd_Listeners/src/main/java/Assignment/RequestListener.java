package Assignment;

import javax.servlet.ServletContext;
import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.annotation.WebListener;

@WebListener
public class RequestListener implements ServletRequestListener {
	public void requestInitialized(ServletRequestEvent sre) {
		ServletContext context = sre.getServletContext();
		Integer count = (Integer) context.getAttribute("visitorCount");
		if(count == null) {
			count=0;
		}
		
		context.setAttribute("visitorCount",count+1);
		
		System.out.println("Request started | Visitors: "+(count+1));
	}

}
