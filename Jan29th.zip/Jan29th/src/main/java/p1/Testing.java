package p1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Testing
 */
@WebServlet("/Testing")
public class Testing extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Testing() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter o= response.getWriter();
//		
//		String name=request.getParameter("firstName");
//		String Address=request.getParameter("address");
//		o.write("Your name is " + name +"\nYour Address is "+Address);
		
//		int number1=Integer.parseInt(request.getParameter("num1"));
//		int number2=Integer.parseInt(request.getParameter("num2"));
//		if(number1>number2) {
//			o.write("Greatest number is "+number1);
//		}else if(number2>number1) {
//			o.write("Greatest number is "+number2);
//		}else {
//			o.write("Both are equal");
//		}
		
		int number1 = Integer.parseInt(request.getParameter("num1"));
		int number2 = Integer.parseInt(request.getParameter("num2"));
		int prime=0;
		for(int i=number1+1;i<number2;i++) {
			int num=i;
			int cnt=0;
			for(int j=2;j<=num/2;j++) {
				if(num%j==0) {
					cnt++;
					break;
				}
			}
			if(cnt==0) { 
				prime++;
			}
			
			
		}
		o.write("Number of prime numbers : "+prime);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
