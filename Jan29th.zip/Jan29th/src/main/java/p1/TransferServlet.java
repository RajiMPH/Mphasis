package p1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class TransferServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String bankName;
	String customerCare;
	int maxLimit;
	
	@Override
	public void init(ServletConfig config) throws ServletException{
		super.init(config);
		maxLimit=Integer.parseInt(config.getInitParameter("maxLimit"));
		
		ServletContext context=config.getServletContext();
		bankName=context.getInitParameter("bankName");
		customerCare=context.getInitParameter("customerCare");
		
		System.out.println("Transfer Service Initialized");
	}
	
//	private static final long serialVersionUID = 1L;
//       
//    /**
//     * @see HttpServlet#HttpServlet()
//     */
//    public TransferServlet() {
//        super();
//        // TODO Auto-generated constructor stub
//    }
//
//	/**
//	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
//	 */
//	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
//	}
//
//	/**
//	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
//	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int amount=Integer.parseInt(request.getParameter("amount"));
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		out.println("<h2>"+bankName+"</h2>");
		if(amount<=maxLimit) {
			out.println("<p>Transfer Successfully</p>");
			out.println("<p>Amount Transfered:$"+amount+"</p>");
		
			
		}else {
			out.println("<p style='color:red'>Transfer Failed</p>");
			out.println("<p>Maximum Limit is $"+maxLimit+"</p>");
		}
		
		out.println("<hr>");
		out.println("<p>Customer care:"+customerCare+"</p>");
		out.println("<a href='Index.html'>Back</a>");
		
	}
	public void destroy() {
		System.out.println("Transfer servlet Destroyed");
	}

}
