package com.example;
import org.springframework.stereotype.Component;

@Component // create object of the class and manage it as a bean
public class BankServiceImpl implements BankService{
	@Override
	public void transferMoney() {
		System.out.println("Money transferred successfully");
	}

}
