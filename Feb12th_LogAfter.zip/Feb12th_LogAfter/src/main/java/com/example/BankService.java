package com.example;

public interface BankService {
	void transferMoney();
}
