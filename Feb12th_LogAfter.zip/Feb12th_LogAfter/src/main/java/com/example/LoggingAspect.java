package com.example;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;


@Aspect
@Component
public class LoggingAspect {
	private static final Logger logger=(Logger) LoggerFactory.getLogger(LoggingAspect.class);
	
	@After("execution(* com.example.BankService.transferMoney(..))")
	public void afterTransfer() {
		System.out.println("Transaction log saved(After Advice)");
		logger.info("Transaction completed and logged successfully.");
	}
	
}
