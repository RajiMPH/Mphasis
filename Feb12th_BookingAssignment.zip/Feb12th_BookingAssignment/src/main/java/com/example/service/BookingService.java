package com.example.service;

import com.example.model.BankDetails;
import com.example.model.Passenger;
import com.example.repository.BankRepository;
import com.example.repository.PassengerRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;

@Service
public class BookingService {

    @Resource private PassengerRepository passengerRepo;
    @Resource private BankRepository bankRepo;

    /**
     * Creates/updates passenger, checks balance and debits atomically.
     * Rolls back on any RuntimeException.
     */
    @Transactional
    public void bookTicket(Integer custId, String name, BigDecimal cost) {
        if (custId == null || name == null || name.isBlank() || cost == null || cost.signum() <= 0) {
            throw new IllegalArgumentException("Invalid input");
        }

        // 1) Ensure passenger exists / insert if new
        Passenger passenger = passengerRepo.findById(custId);
        if (passenger == null) {
            passenger = new Passenger();
            passenger.setCustId(custId);
            passenger.setCustName(name.trim());
            passengerRepo.saveOrUpdate(passenger);
        } else {
            // Optional: keep DB name authoritative or update name from form
            passenger.setCustName(name.trim());
            passengerRepo.saveOrUpdate(passenger);
        }

        // 2) Load bank details for this passenger
        BankDetails bank = bankRepo.findByPassenger(passenger);
        if (bank == null) {
            throw new IllegalStateException("No bank account found for customer: " + custId);
        }

        // 3) Check & debit
        BigDecimal newBalance = bank.getBalance().subtract(cost);
        if (newBalance.signum() < 0) {
            // Triggers rollback automatically due to @Transactional
            throw new IllegalStateException("Insufficient balance");
        }

        bank.setBalance(newBalance);
        bankRepo.saveOrUpdate(bank);
        // End of method -> commit if no exception (ACID)
    }
}