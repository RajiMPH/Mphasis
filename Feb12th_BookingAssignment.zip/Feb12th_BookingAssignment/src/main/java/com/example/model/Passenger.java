package com.example.model;

import javax.persistence.*;

@Entity
@Table(name = "passengers")
public class Passenger {

    @Id
    @Column(name = "cust_id")
    private Integer custId;

    @Column(name = "cust_name", nullable = false, length = 50)
    private String custName;

    // getters/setters
    public Integer getCustId() { return custId; }
    public void setCustId(Integer custId) { this.custId = custId; }
    public String getCustName() { return custName; }
    public void setCustName(String custName) { this.custName = custName; }
}
