package com.example.model;

import javax.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "bank_details")
public class BankDetails {

    @Id
    @Column(name = "acc_no")
    private Integer accNo;

    @Column(name = "balance", nullable = false, precision = 12, scale = 2)
    private BigDecimal balance;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cust_id", nullable = false, unique = true,
                foreignKey = @ForeignKey(name = "fk_bank_passenger"))
    private Passenger passenger;

    // getters/setters
    public Integer getAccNo() { return accNo; }
    public void setAccNo(Integer accNo) { this.accNo = accNo; }

    public BigDecimal getBalance() { return balance; }
    public void setBalance(BigDecimal balance) { this.balance = balance; }

    public Passenger getPassenger() { return passenger; }
    public void setPassenger(Passenger passenger) { this.passenger = passenger; }
}