package com.example.repository;

import com.example.model.Passenger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;

@Repository
public class PassengerRepository {
    @Resource
    private SessionFactory sessionFactory;

    private Session currentSession() {
        return sessionFactory.getCurrentSession();
    }

    public Passenger findById(Integer custId) {
        return currentSession().get(Passenger.class, custId);
    }

    public void saveOrUpdate(Passenger p) {
        currentSession().saveOrUpdate(p);
    }
}