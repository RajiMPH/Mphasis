package com.example.repository;

import com.example.model.BankDetails;
import com.example.model.Passenger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;

@Repository
public class BankRepository {
    @Resource
    private SessionFactory sessionFactory;

    private Session currentSession() {
        return sessionFactory.getCurrentSession();
    }

    public BankDetails findByPassenger(Passenger passenger) {
        String hql = "from BankDetails b where b.passenger = :p";
        return currentSession()
                .createQuery(hql, BankDetails.class)
                .setParameter("p", passenger)
                .uniqueResult();
    }

    public void saveOrUpdate(BankDetails b) {
        currentSession().saveOrUpdate(b);
    }
}
