package com.example.controller;

import com.example.service.BookingService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.ui.Model;

import javax.annotation.Resource;
import java.math.BigDecimal;

@Controller
public class BookingController {

    @Resource
    private BookingService bookingService;

    @GetMapping("/book-ticket")
    public String bookingPage() {
        return "booking"; // resolves to /WEB-INF/views/booking.jsp
    }

    @PostMapping("/book-ticket")
    public String handleBooking(
            @RequestParam("CustId") Integer custId,
            @RequestParam("user") String name,
            @RequestParam("cost") BigDecimal cost,
            Model model) {

        try {
            bookingService.bookTicket(custId, name, cost);
            model.addAttribute("message", "Passenger number " + custId + " your ticket is booked");
            model.addAttribute("success", true);
        } catch (Exception ex) {
            model.addAttribute("message", ex.getMessage());
            model.addAttribute("success", false);
        }
        return "result";
    }
}