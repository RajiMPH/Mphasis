//package Reset;
//
//import java.io.IOException;
//import java.sql.*;
//
//import javax.servlet.Filter;
//import javax.servlet.FilterChain;
//import javax.servlet.FilterConfig;
//import javax.servlet.ServletException;
//import javax.servlet.ServletRequest;
//import javax.servlet.ServletResponse;
//import javax.servlet.annotation.WebFilter;
//import javax.servlet.http.HttpFilter;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//import org.apache.catalina.connector.Response;
//
//import DBConnection.DBUtil;
//
////**
//// * Servlet Filter implementation class ResetPasswordFilter
//// */
//@WebFilter("/Reset")
//public class ResetPasswordFilter extends HttpFilter implements Filter {
//       
//
//	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
//		HttpServletRequest req = (HttpServletRequest) request;
//		HttpServletResponse res = (HttpServletResponse) response;
//		
//		
//		if (!"POST".equalsIgnoreCase(req.getMethod())) {
//	        chain.doFilter(request, response);
//	        return;
//	    }
//		
//		String empId = req.getParameter("employeeId");
//	    String newPassword = req.getParameter("newPassword");
//
//	    if (empId == null || empId.trim().isEmpty()) {
//	        res.sendRedirect("ResetPassword.html?error=invalidEmployee");
//	        return;
//	    }
//
//	    empId = empId.trim();
//
//	    // ✅ Convert to int (DB column is INT)
//	    int empIdInt;
//	    try {
//	        empIdInt = Integer.parseInt(empId);
//	    } catch (NumberFormatException e) {
//	        res.sendRedirect("ResetPassword.html?error=invalidEmployee");
//	        return;
//	    }
//
//	    if (!isEmployeeExists(empIdInt)) {
//	        res.sendRedirect("ResetPassword.html?error=invalidEmployee");
//	        return;
//	    }
//
//	    if (!isPasswordValid(newPassword)) {
//	        res.sendRedirect("ResetPassword.html?error=invalidPassword");
//	        return;
//	    }
//
//	    chain.doFilter(request, response);
//	}
//
//	/**
//	 * @see Filter#init(FilterConfig)
//	 */
//	
//	
//	private boolean isEmployeeExists(int empId) {
//		boolean exists = false;
//
//	    try (Connection con = DBUtil.getConnection();
//	         PreparedStatement ps =
//	                 con.prepareStatement("SELECT * FROM employee WHERE Emp_Id = ?")) {
//
//	        ps.setInt(1, empId);
//	        ResultSet rs = ps.executeQuery();
//
//	        if(rs.next()) {
//	        	exists=true;
//	        }
//
//	    } catch (Exception e) {
//	        e.printStackTrace();
//	    }
//
//	    return exists;
//
//	}
//	
//	private boolean isPasswordValid(String pass) {
//		if(pass == null) {
//			return false;
//		}
//		String pattern = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%!]).{8,}$";
//		
//		return pass.matches(pattern);
//	}
//	public void init(FilterConfig fConfig) throws ServletException {
//		// TODO Auto-generated method stub
//	}
//
//}
package Reset;
import DBConnection.DBUtil;
import java.io.IOException;
import java.sql.*;

import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebFilter("/Reset")
public class ResetPasswordFilter implements Filter {

    private static final String PASSWORD_REGEX =
            "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$";

    @Override
    public void doFilter(ServletRequest request,
                         ServletResponse response,
                         FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;

        String employeeId = req.getParameter("employeeId");
        String newPassword = req.getParameter("newPassword");
        String confirmPassword = req.getParameter("confirmPassword");

        try {
            Connection con = DBUtil.getConnection();

            // 1. Check employee exists
            PreparedStatement ps =
                    con.prepareStatement(
                        "SELECT employee_id FROM users WHERE employee_id=?");

            ps.setString(1, employeeId);
            ResultSet rs = ps.executeQuery();

            if (!rs.next()) {
                res.sendRedirect("ResetPassword.jsp?error=notMphasisEmployee");
                return;
            }

            // 2. Check password match
            if (!newPassword.equals(confirmPassword)) {
                res.sendRedirect("ResetPassword.jsp?error=invalidPassword");
                return;
            }

            // 3. Password constraint validation
            if (!Pattern.matches(PASSWORD_REGEX, newPassword)) {
                res.sendRedirect("ResetPassword.jsp?error=invalidPassword");
                return;
            }

            // All validations passed
            chain.doFilter(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            res.sendRedirect("ResetPassword.jsp?error=invalidPassword");
        }
    }
}
