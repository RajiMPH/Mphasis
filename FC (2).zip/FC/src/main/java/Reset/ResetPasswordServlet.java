//package Reset;
//
//import java.io.IOException;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//import DBConnection.DBUtil;
//import Login.PasswordUtil;
//
//@WebServlet("/Reset")
//public class ResetPasswordServlet extends HttpServlet {
//
//    @Override
//    protected void doPost(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//
//        String empIdStr = request.getParameter("employeeId");
//        String newPassword = request.getParameter("newPassword");
//        String confirmPassword = request.getParameter("confirmPassword");
//
//        /* ===============================
//           1️⃣ Validate Employee ID
//        =============================== */
//        if (empIdStr == null || empIdStr.trim().isEmpty()) {
//            response.sendRedirect("ResetPassword.html?error=invalidEmployee");
//            return;
//        }
//
//        int empId;
//        try {
//            empId = Integer.parseInt(empIdStr.trim());
//        } catch (NumberFormatException e) {
//            response.sendRedirect("ResetPassword.html?error=invalidEmployee");
//            return;
//        }
//
//        if (!employeeExists(empId)) {
//            response.sendRedirect("ResetPassword.html?error=invalidEmployee");
//            return;
//        }
//
//        /* ===============================
//           2️⃣ Validate Password
//        =============================== */
//        if (newPassword == null || confirmPassword == null ||
//                !newPassword.equals(confirmPassword)) {
//            response.sendRedirect("ResetPassword.html?error=invalidPassword");
//            return;
//        }
//
//        if (!isPasswordValid(newPassword)) {
//            response.sendRedirect("ResetPassword.html?error=invalidPassword");
//            return;
//        }
//
//        /* ===============================
//           3️⃣ Hash & Update Password
//        =============================== */
//        String hashedPassword = PasswordUtil.hashPassword(newPassword);
//        updatePassword(empId, hashedPassword);
//
//        /* ===============================
//           4️⃣ Success → Login
//        =============================== */
//        response.sendRedirect("Login.html?success=true");
//    }
//
//    /* ===============================
//       DB METHODS
//    =============================== */
//
//    private boolean employeeExists(int empId) {
//        String sql = "SELECT 1 FROM employee WHERE Emp_Id = ?";
//        try (Connection con = DBUtil.getConnection();
//             PreparedStatement ps = con.prepareStatement(sql)) {
//
//            ps.setInt(1, empId);
//            ResultSet rs = ps.executeQuery();
//            return rs.next();
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return false;
//    }
//
//    private void updatePassword(int empId, String hash) {
//        String sql = "UPDATE employee SET Emp_Hash_Password = ? WHERE Emp_Id = ?";
//        try (Connection con = DBUtil.getConnection();
//             PreparedStatement ps = con.prepareStatement(sql)) {
//
//            ps.setString(1, hash);
//            ps.setInt(2, empId);
//            ps.executeUpdate();
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//    private boolean isPasswordValid(String pass) {
//        String pattern =
//                "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%!]).{8,}$";
//        return pass != null && pass.matches(pattern);
//    }
//}


package Reset;

import DBConnection.DBUtil;
import Login.PasswordUtil;
import java.io.IOException;
import java.security.MessageDigest;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Reset")
public class ResetPasswordServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String employeeId = request.getParameter("employeeId");
        String newPassword = request.getParameter("newPassword");

        try {
            // Hash password
            String hashedPassword = PasswordUtil.hashPassword(newPassword);

            Connection con = DBUtil.getConnection();

            PreparedStatement ps = con.prepareStatement(
                    "UPDATE users SET password=? WHERE employee_id=?");

            ps.setString(1, hashedPassword);
            ps.setString(2, employeeId);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                response.sendRedirect("login.jsp?error=success");
            } else {
                response.sendRedirect("ResetPassword.html?error=updateFailed");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("ResetPassword.html?error=serverError");
        }
    }

    
}
