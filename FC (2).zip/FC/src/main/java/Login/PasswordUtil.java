package Login;

import java.security.MessageDigest;

public class PasswordUtil {
	public static String hashPassword(String password)throws Exception {

		MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hashBytes = md.digest(password.getBytes("UTF-8"));

        StringBuilder hexString = new StringBuilder();
        for (byte b : hashBytes) {
            hexString.append(String.format("%02x", b));
        }

        return hexString.toString();
	}
}
