package Login;

import DBConnection.DBUtil;
import java.io.IOException;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebFilter;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebFilter("/Dashboard")
public class LoginFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request,
                         ServletResponse response,
                         FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;

        String employeeId = req.getParameter("employeeId");
        String password = req.getParameter("password");

        try {
            Connection con = DBUtil.getConnection();

            PreparedStatement ps = con.prepareStatement(
                "SELECT password FROM users WHERE employee_id=?"
            );

            ps.setInt(1, Integer.parseInt(employeeId));

            ResultSet rs = ps.executeQuery();

            // Employee not found
            if (!rs.next()) {
                res.sendRedirect("login.jsp?error=invalid");
                return;
            }

            String storedHash = rs.getString("password");

            // Hash entered password
            String enteredHash = PasswordUtil.hashPassword(password);

            // Compare hashes
            if (!storedHash.equals(enteredHash)) {
                res.sendRedirect("login.jsp?error=invalid");
                return;
            }

            // Login success
            chain.doFilter(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            res.sendRedirect("login.jsp?error=invalid");
        }
    }

}
