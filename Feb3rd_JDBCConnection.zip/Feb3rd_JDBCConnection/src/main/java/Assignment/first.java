package Assignment;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;






@WebServlet("/first")
public class first extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		out.println("<h2>Student List</h2>");
		try {
			// 1. Load Driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			// 2. Create Connection
			Connection con = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/mphasis",
				"root",
				"root@39"
			);
			
			// 3. Create Statement
			Statement stmt = con.createStatement();
			// 4. Execute Query
			ResultSet rs = stmt.executeQuery("SELECT * FROM employee");
			
			out.println("<table border='1'>");
			out.println("<tr><th>ID</th><th>Name</th><th>Salary</th></tr>");
			// 5. Process ResultSet
			
			
			while (rs.next()) {
				out.println("<tr>");
				out.println("<td>" + rs.getInt("id") + "</td>");
				out.println("<td>" + rs.getString("name") + "</td>");
				
				out.println("<td>" + rs.getInt("salary") + "</td>");
				out.println("</tr>");
				
			}
			
			out.println("</table>");
			
			// 6. Close resources
			rs.close();
			stmt.close();
			con.close();
			
		} catch (Exception e) {
				out.println("Error: " + e.getMessage());
		}
		
		
	}


}


