package Assignment;

import java.io.IOException;
import java.io.PrintWriter;

import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class QueryServlet
 */
@WebServlet("/QueryServlet")
public class QueryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public QueryServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		doGet(request, response);
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<h1>Student Details</h1>");
		
		int id=Integer.parseInt(request.getParameter("id"));
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/mphasis",
					"root",
					"root@39"
			);
			
			String sqlQ = "SELECT * FROM EMPLOYEE WHERE id = ?";
			PreparedStatement ps = con.prepareStatement(sqlQ);
			ps.setInt(1, id);
			
			ResultSet rs = ps.executeQuery();
			if(!rs.next()) {
				out.println("<tr><td colspan='3'>No record found for id = " + id + "</td></tr>");
			}else {
				out.println("<table border='1'>");
				out.println("<tr><th>ID</th><th>Name</th><th>Salary</th></tr>");

				
				while (rs.next()) {
				
					out.println("<tr>");
					out.println("<td>" + rs.getInt("id") + "</td>");
					out.println("<td>" + rs.getString("name") + "</td>");
					out.println("<td>" + rs.getInt("salary") + "</td>");
					out.println("</tr>");
				}
			}
			

//			if (!any) {
//				out.println("<tr><td colspan='3'>No record found for id = " + id + "</td></tr>");
//			}
			
			
			
					
		}catch(Exception e) {
			response.getWriter().println("<pre>" + e.toString() + "</pre>");

		}
		
		
		
	}

}
