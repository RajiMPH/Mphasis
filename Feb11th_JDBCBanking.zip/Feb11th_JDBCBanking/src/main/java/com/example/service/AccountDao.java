package com.example.service;

import org.springframework.jdbc.core.JdbcTemplate;

public class AccountDao {

    private JdbcTemplate jdbcTemplate;

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public boolean exists(int acno) {
        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM Account WHERE AccNo = ?",
                Integer.class, acno);
        return count != null && count > 0;
    }

    public int getBalance(int acno) {
        Integer bal = jdbcTemplate.queryForObject(
                "SELECT balance FROM Account WHERE AccNo = ?",
                Integer.class, acno);
        return (bal == null) ? 0 : bal;
    }

    /** Update balance */
    public int updateBalance(int acno, int newBalance) {
    	String sql = "UPDATE Account SET balance = ? WHERE AccNo = ?";
        return jdbcTemplate.update(sql,
                newBalance, acno);
    }
}
