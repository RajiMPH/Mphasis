package com.example.service;

public class BankService {

    private AccountDao accountDao;

    public void setAccountDao(AccountDao accountDao) {
        this.accountDao = accountDao;
    }

    
    public void withdrawMoney(int accountNo, int amount) {
        int current = accountDao.getBalance(accountNo);
        int updated = current - amount;   // This assumes the AOP's optional "amount <= balance" check is enabled.
        accountDao.updateBalance(accountNo, updated);
        System.out.println("Success: Withdrawn " + amount +
                           " from account " + accountNo +
                           ". New balance = " + updated);
    }
}