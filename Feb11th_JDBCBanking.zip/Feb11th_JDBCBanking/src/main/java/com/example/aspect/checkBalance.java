package com.example.aspect;

import com.example.service.AccountDao;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class checkBalance {

    private AccountDao accountDao;

    public void setAccountDao(AccountDao accountDao) {
        this.accountDao = accountDao;
    }

    
    @Before("execution(* com.example.service.*.*(..)) && args(accountNo, amount)")
    public void checkBal(int accountNo, int amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Withdrawal amount must be positive.");
        }

        if (!accountDao.exists(accountNo)) {
            throw new IllegalArgumentException("Account " + accountNo + " does not exist.");
        }

        int balance = accountDao.getBalance(accountNo);

        if (balance <= 1000) {
            throw new IllegalStateException(
                "Withdrawal not allowed. Current balance " + balance + " must be > 1000.");
        }

        if (amount > balance) {
            throw new IllegalStateException(
                "Insufficient funds. Trying to withdraw " + amount + " but balance is " + balance + ".");
        }
    }
}