package com.example.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.service.BankService;

public class Withdraw {
	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("com/example/main/con1.xml");
		BankService serv = ctx.getBean(BankService.class);
		
		try {
			
			serv.withdrawMoney(2708,250);
			serv.withdrawMoney(3030,4000);
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
