package Employees;

import javax.persistence.*;
@Entity
@Table(name = "Employee")
//@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
//@Inheritance(strategy = InheritanceType.TABLE_PER_COLUMN)
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn(
		name="EMP_TYPE",
		discriminatorType = DiscriminatorType.STRING
	)

public class Employee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	private int id;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
