package Employees;

import javax.persistence.*;
@Entity
@DiscriminatorValue("PERMANENT")
public class PermanentEmployee extends Employee{
	
	public double getSalary() {
		return salary;
	}
	
	private double salary;

	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	
}
