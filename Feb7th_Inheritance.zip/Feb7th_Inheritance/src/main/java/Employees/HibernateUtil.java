package Employees;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {
    private static final SessionFactory sessionFactory = buildSessionFactory();
//session factory is created 
    private static SessionFactory buildSessionFactory() {
        try {
            // Loads hibernate.cfg.xml from resources/
            return new Configuration().configure().buildSessionFactory();
        } catch (Throwable ex) {
            System.err.println("SessionFactory creation failed: " + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }
//hibernate will look for configuration file in resources folder 
    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }
//provides a global access point 
    public static void shutdown() {
        getSessionFactory().close();
    }
}
//when the app stops we must call shutdown to release the resources 

