package Employees;
import javax.persistence.*;

@Entity
@DiscriminatorValue("CONTRACT")
public class ContractEmployee extends Employee{
	private double hourlyPay;

	public double getHourlyPay() {
		return hourlyPay;
	}

	public void setHourlyPay(double hourlyPay) {
		this.hourlyPay = hourlyPay;
	}
	
	
}
