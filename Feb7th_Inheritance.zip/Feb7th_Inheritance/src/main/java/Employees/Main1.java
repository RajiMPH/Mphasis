package Employees;

import org.hibernate.*;

import org.hibernate.Session;

public class Main1 {
	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		Transaction tx = null;
		
		try {
			
			tx=(Transaction) session.beginTransaction();
			PermanentEmployee p=new PermanentEmployee();
			p.setName("Raji");
			p.setSalary(100000);
			
			ContractEmployee c = new ContractEmployee();
			c.setName("Vendru");
			c.setHourlyPay(500);
			
			
			session.save(p);
			session.save(c);
			
			tx.commit();
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}finally {
			session.close();
		}
		
	}
}
