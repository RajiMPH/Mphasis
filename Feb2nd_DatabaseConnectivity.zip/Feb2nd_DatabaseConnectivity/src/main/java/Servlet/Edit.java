package Servlet;
import Student_Details.Students;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Edit
 */
@WebServlet("/Edit")
public class Edit extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Edit() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		
		String id = request.getParameter("id");
		HttpSession s1 = request.getSession();
//		response.sendRedirect("Edit.html?userid ="+id);

		String url = request.getContextPath() + "/Edit.html?userid=" + id;
        response.sendRedirect(response.encodeRedirectURL(url));

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		doGet(request, response);
		
//		int id=Integer.parseInt

		int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        String course = request.getParameter("course");


		List<Students> students = (List<Students>) getServletContext().getAttribute("students");
        if (students == null) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Students list not initialized");
            return;
        }

            
		boolean updated = false;
        for (Students s : students) {
            if (s.getId() == id) {
                // Update the existing object
                s.setName(name);
                s.setCourse(course);
                updated = true;
                break;
            }
        }
        
        response.sendRedirect("StudentServlet");

	}
}
	
