package Servlet;

import Student_Details.Students;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class StudentServlet
 */
@WebServlet("/StudentServlet")
public class StudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	List<Students> students = new ArrayList<>();
    public StudentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    public void init(ServletConfig config) throws ServletException{
    	super.init(config);
    	
		students.add(new Students(1,"Raji","ECE"));
		students.add(new Students(2,"Ilakkiya","Bpharm"));
		students.add(new Students(3,"Nandhini","ECE"));
		students.add(new Students(4,"Sathya","ECE"));
		students.add(new Students(5,"Kamali","ECE"));
		getServletContext().setAttribute("students", students);
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<head><title>Student List</title></head>");
		out.println("<body>");
		
		out.println("<h2>Student list (HTML only MVC) </h2>");
		out.println("<table border='1'>");
		out.println("<tr><th>ID</th><th>Name</th><th>Course</th><th>Update</th><th>Delete</th></tr>");
		
		for(Students s: students) {
			out.println("<tr>");
			out.println("<td>" + s.getId() + "</td>");
			out.println("<td>" + s.getName() + "</td>");
			out.println("<td>" + s.getCourse() + "</td>");

			out.println("<td><a href='" + request.getContextPath() + "/Edit?id=" + s.getId() + "'>Edit</a></td>");
			out.println("<td><a href='" + request.getContextPath() + "/Remove?id=" + s.getId() + "'>Remove</a></td>");
			out.println("</tr>");
			
			
		}
		out.println("</table>");
		out.println("</body></html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		doGet(request, response);
		
		
		
		List<Students> students = (List<Students>) getServletContext().getAttribute("students");
		
		int id = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name");
		String course = request.getParameter("course");
		
		students.add(new Students(id,name,course));	
		response.sendRedirect("index.html");
		
		
	}

}
