package model;


public class User {
	private String username;
	
	public User(String uname) {
		this.username = uname;
	}
	
	public String getUsername() {
		return username;
	}
}
