package dao;

import model.User;
public class UserDAO {
	public User validate(String username,String password) {
		if(("Raji".equals(username)) &&("RajiIlakkiya".equals(password))) {
			return new User(username);
		}
		return null;
	}

}
