package Constructor_Injection;

public class Engine {
	public void start() {
		System.out.println("Engine Started");
	}
}
