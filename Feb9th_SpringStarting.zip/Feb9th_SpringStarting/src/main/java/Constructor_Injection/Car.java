package Constructor_Injection;

public class Car {
	private Engine engine;
	
	//Taking obj as parameter
	public Car(Engine engine) {
		this.engine=engine;
	}
	
	public void drive() {
		engine.start();
		System.out.println("Car is moving");
	}
}
