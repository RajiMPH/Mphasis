package ConstructorInjection_UsingAnnotation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main1 {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("ConstructorInjection_UsingAnnotation/Engines.xml");
		Car c1 = context.getBean(Car.class);
		c1.drive();
	}

}
