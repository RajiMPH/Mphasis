package ConstructorInjection_UsingAnnotation;

public class Engine {
	public void start() {
		System.out.println("Engine Started");
	}
}
