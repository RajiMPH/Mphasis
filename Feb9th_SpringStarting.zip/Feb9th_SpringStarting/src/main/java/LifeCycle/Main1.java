package LifeCycle;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main1 {
	public static void main(String[] args) {
		try {
			AbstractApplicationContext ac = new ClassPathXmlApplicationContext("LifeCycle/life.xml");
			Car o = (Car)ac.getBean("bean1");
			System.out.println(o);
			//forcing to destroy
			ac.registerShutdownHook();
			
		}catch(Exception m) {
			System.out.println("error:" +m.getMessage());
		}
		
		
		
	}
}
