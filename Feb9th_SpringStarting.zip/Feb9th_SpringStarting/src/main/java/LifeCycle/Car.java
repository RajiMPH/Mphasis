package LifeCycle;


import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;


public class Car {
	private double price;
	
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		System.out.println("SETTER PRICE OF CAR ");
		this.price = price;
	}
	@PostConstruct
	public void F1(){
		System.out.println("IT IS INSIDE INIT METHOD");
	}
	
	@PreDestroy
	public void F2(){
		System.out.println("ABOUT TO DESTRROY");
	}
	
	@PostConstruct
	public void Car(){
		System.out.println("I AM CONSTRUCTOR "); 
	}
	public void Car(double price) {
		this.price = price;
		System.out.println("i am mphasis");
	}

	@Override
	public String toString() {
		return "Car{" + "price=" + price + '}';
	}
}
