package Employees;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class Main1 {
	public static void main(String[] args) {
		System.out.println("main");
		ApplicationContext context = new ClassPathXmlApplicationContext("Employees/cart.xml");
		Employee ee=(Employee)context.getBean("obj");
		System.out.println(ee);
	}
}
