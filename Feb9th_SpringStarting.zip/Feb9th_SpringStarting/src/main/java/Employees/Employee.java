package Employees;

public class Employee {
	private String Name;
	private int Age;
	private Address address;
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		Age = age;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
	
	public String toString() {
		return "Employee [Name=" +Name+", Age=" + Age +", address=" + address+"]";
	}
}
