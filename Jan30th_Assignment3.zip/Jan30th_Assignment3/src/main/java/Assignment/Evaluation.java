package Assignment;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Evaluation
 */
@WebServlet("/Evaluation")
public class Evaluation extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	
	Map<String,String> Answers;
	
    public Evaluation() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
    	Answers = new HashMap<>();
    	
    	Answers.put("ans1", "4");
    	Answers.put("ans2", "55");
    	Answers.put("ans3", "125");
    	
    	
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		doGet(request, response);
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		Map<String,String> Res = new HashMap<>();
		
		int marks = 0 ;
		String ans1 = request.getParameter("ans1");
		String ans2 = request.getParameter("ans2");
		String ans3 = request.getParameter("ans3");
		
		Res.put("ans1",ans1);
		Res.put("ans2",ans2);
		Res.put("ans3",ans3);
		
		for (Map.Entry<String, String> entry : Res.entrySet()) {
			
			String key = entry.getKey();
			String value = entry.getValue();
		    if(value.equals(Answers.get(key))){
		    	marks+=1;
		    }
		}
		HttpSession s1 = request.getSession();
		s1.setAttribute("marks", marks);
		
		
//		RequestDispatcher ch = request.getRequestDispatcher("Exam");
//		ch.forward(request, response);
				
		response.sendRedirect(request.getContextPath()+"/Exam");
				
		
		
	}

}
