package Assignment;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Exam
 */
@WebServlet("/Exam")
public class Exam extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	
	Map<Integer,String> Participants = new HashMap<>();
	int userid;
	String name;
	
    public Exam() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
//	public void init(ServletConfig config) throws ServletException {
//		// TODO Auto-generated method stub
//	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
//	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		// TODO Auto-generated method stub
//		
//		super.service(request, response);
//	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		
//		response.setContentType("text/html");
//		PrintWriter out=response.getWriter();
//		
//		HttpSession s2 = request.getSession();
//		Integer Marks = (Integer)s2.getAttribute("marks");
//		if(Marks == null) Marks=0;
//
//		out.println("<h3>"+ userid + ". "+ name + " You have got "+Marks + " marks.</h2>");
//		
		
		response.setContentType("text/html;charset=UTF-8");
	    PrintWriter out = response.getWriter();

	    HttpSession s2 = request.getSession(false);

	    Integer userid = null;
	    String name = null;
	    Integer marks = null;

	    if (s2 != null) {
	        userid = (Integer) s2.getAttribute("userid");
	        name = (String) s2.getAttribute("name");
	        marks = (Integer) s2.getAttribute("marks");
	    }
	    if (marks == null) marks = 0;

	    out.println("<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Exam Result</title></head><body>");

	    if (userid == null || name == null) {
	        out.println("<h3>No registration found in session. Please register again.</h3>");
	        out.println("ExamRegistration.htmlBack to Registration</a>");
	    } else {
	        out.println("<h3>" + userid + ". " + name + ", you have got " + marks + " marks.</h3>");
	        out.println("<a href=ExamRegistration.html>Back to Registration</a>");
	    }

	    out.println("</body></html>");
	    
	    
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
//		userid = Integer.parseInt(request.getParameter("userid"));
//		name = request.getParameter("name");
//		
//		if(Participants.containsKey(userid)) {
//			response.sendRedirect("ExaminationOver.html");
//			return;
//		}else {
//			Participants.put(userid,name);
//			response.sendRedirect("Questions.html");
//		}
		

		String useridStr = request.getParameter("userid");
	    String name = request.getParameter("name");
	
	    // If userid is missing, this is NOT a registration call; likely a forward from Evaluation.
	    if (useridStr == null || name == null) {
	        // Just show the result page
	        doGet(request, response);
	        return;
	    }
	
	    // Registration flow
	    int userid = Integer.parseInt(useridStr);
	
	    if (Participants.containsKey(userid)) {
	        response.sendRedirect("ExaminationOver.html");
	        return;
	    } else {
	        Participants.put(userid, name);
	
	        // Save to session for later rendering
	        HttpSession session = request.getSession();
	        session.setAttribute("userid", userid);
	        session.setAttribute("name", name);
	
	        response.sendRedirect("Questions.html");
	    }

		
		
		
	}
//		doGet(request, response);


}


