package Feb12th_boot.Feb12th_boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Feb12thBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(Feb12thBootApplication.class, args);
	}

}
