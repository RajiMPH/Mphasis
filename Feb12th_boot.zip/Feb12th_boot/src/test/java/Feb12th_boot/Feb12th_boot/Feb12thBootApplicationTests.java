package Feb12th_boot.Feb12th_boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Feb12thBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
