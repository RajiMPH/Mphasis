package pack;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
    public static void main(String[] args) {

        ApplicationContext ctx =
                new ClassPathXmlApplicationContext("pack/beans.xml");

        EmployeeDAO dao = ctx.getBean("employeeDAO", EmployeeDAO.class);

        // CREATE
        Employee e1 = new Employee();
        e1.setId(2);
        e1.setName("Raj");
        e1.setSalary(4400);
        dao.save(e1);

        // UPDATE
//        e1.setSalary(50000);
//        dao.update(e1);

        // READ ONE
//        Employee e = dao.getById(1);
//        System.out.println(e.getName() + " " + e.getSalary());

        // READ ALL
//        dao.getAll().forEach(emp ->
//                System.out.println(emp.getId() + " " + emp.getName())
//        );

        // DELETE
//        dao.delete(1);
    }
}
