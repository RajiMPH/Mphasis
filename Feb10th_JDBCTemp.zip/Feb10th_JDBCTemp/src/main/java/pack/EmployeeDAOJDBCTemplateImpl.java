package pack;
import org.springframework.jdbc.core.JdbcTemplate;
import java.util.List;
public class EmployeeDAOJDBCTemplateImpl implements EmployeeDAO {
	private JdbcTemplate jdbcTemplate;
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	public void save(Employee e) {
		String sql="INSERT INTO employee VALUES(?,?,?)";
		jdbcTemplate.update(sql,e.getId(),e.getName(),e.getSalary());
		System.out.println("Employee inserted");
	}
	
	public void update(Employee e) {
		String sql="UPDATE employee SET name=?,salary=? WHERE id=?";
		jdbcTemplate.update(sql,e.getId(),e.getName(),e.getSalary());
		System.out.println("Employee updated");
	}
	
	public void delete(int id) {
		String sql="DELETE FROM employee WHERE id=?";
		jdbcTemplate.update(sql,id);
		System.out.println("Employee deleted");
	}
	
	public Employee getById(int id) {
		String sql="SELECT * FROM employee WHERE id=?";
		return (Employee) jdbcTemplate.queryForObject(sql, new EmployeeRowMapper(), id);
	}
	public List<Employee> getAll(){
		String sql="SELECT * FROM  employee";
		return jdbcTemplate.query(sql,new EmployeeRowMapper());
	}
}
