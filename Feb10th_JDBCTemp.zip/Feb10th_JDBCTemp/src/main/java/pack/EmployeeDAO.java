package pack;

import java.util.List;

public interface EmployeeDAO {
	void save(Employee e);		//create
	void update(Employee e);	//update
	void delete(int id);		//delete
	Employee getById(int id);	//read one	
	List<Employee> getAll();	//read all
}
