package com.example.Feb13th_DBConnection1;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class EmployeeService {
	private final EmployeeRepository repository;
	
	public EmployeeService(EmployeeRepository repository) {
		this.repository=repository;
	}
	
	public Employee save(Employee employee) {
		return repository.save(employee);
	}
	
	public List<Employee> getAll(){
		return repository.findAll();
	}
	
	public Employee getById(Long id) {
		return repository.findById(id).orElseThrow();
	}
	
	public Employee update(Long id,Employee emp) {
		Employee existing = repository.findById(id).orElseThrow();
		existing.setName(emp.getName());
		existing.setSalary(emp.getSalary());
		return repository.save(existing);
	}
	
	public void delete(Long id) {
		repository.deleteById(id);
	}
}
