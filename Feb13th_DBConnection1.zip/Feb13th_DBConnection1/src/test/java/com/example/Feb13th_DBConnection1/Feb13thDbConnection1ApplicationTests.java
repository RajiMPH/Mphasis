package com.example.Feb13th_DBConnection1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Feb13thDbConnection1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
