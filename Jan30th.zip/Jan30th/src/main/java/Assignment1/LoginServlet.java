package Assignment1;

import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */


public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
//       
//    /**
//     * @see HttpServlet#HttpServlet()
//     */
//    public LoginServlet() {
//        super();
//        // TODO Auto-generated constructor stub
//    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    
    private final Map<String,String> users = new HashMap<>();
    
    @Override
    public void init(ServletConfig config) throws ServletException{
    	super.init(config);
    	
    	Enumeration<String> ParamNames = config.getInitParameterNames();
    	
    	while(ParamNames.hasMoreElements()) {
    		String username = ParamNames.nextElement();
    		String password = config.getInitParameter(username);
    		users.put(username,password);
    	}
    	
    	System.out.println("User Map Initialized: "+users);
    	
    }
    
    
//    public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//    	String username = request.getParameter("username");
//    	String password = request.getParameter("pass");
//    	
//    	HttpSession s1=request.getSession();
//    	Integer attempts = (Integer)s1.getAttribute("attempts");
//    	
//    	if(attempts == null) {
//    		attempts=0;
//    	}
//    	
//    	if(users.containsKey(username) && users.get(username).equals(password)) {
//    		s1.invalidate();
//    		response.sendRedirect("success.html");
//    	}else {
//    		attempts++;
//    	}
//    	
//    	if(attempts>=3) {
//    		response.sendRedirect("blocked.html");
//    		
//    	}else {
//    		response.sendRedirect("failure.html");
//    	}
//    }
    
    
    
//	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		// TODO Auto-generated method stub
//		
//		response.getWriter().append("Served at: ").append(request.getContextPath());
//	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username = request.getParameter("username");
    	String password = request.getParameter("pass");
    	
    	HttpSession s1=request.getSession();
    	Integer attempts = (Integer)s1.getAttribute("attempts");
    	
    	if(attempts == null) {
    		attempts=0;
    	}
    	
    	if(users.containsKey(username) && users.get(username).equals(password)) {
    		s1.invalidate();
    		response.sendRedirect("success.html");
    		return;
    	}else {
    		attempts++;
    		s1.setAttribute("attempts", attempts);
    	}
    	
    	if(attempts>=3) {
    		response.sendRedirect("blocked.html");
    		
    	}else {
    		response.sendRedirect("failure.html");
    	}
//		doGet(request, response);
	}
	public void destroy() {
    	users.clear();
    	System.out.println("Servlet Destroyed & Resources released");
    }

}
