//package Assignment2;
//
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.Map;
//
//import javax.servlet.ServletConfig;
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
///**
// * Servlet implementation class ShoppingCart
// */
////@WebServlet("/shop")
//public class ShoppingCart extends HttpServlet {
//	private static final long serialVersionUID = 1L;
//	
//	Map<String,Integer> products;
//	
//	Map<String,Integer> cart;
//       
//    /**
//     * @see HttpServlet#HttpServlet()
//     */
//    public ShoppingCart() {
//        super();
//        // TODO Auto-generated constructor stub
//    }
//
//	/**
//	 * @see Servlet#init(ServletConfig)
//	 */
//	public void init(ServletConfig config) throws ServletException {
//		// TODO Auto-generated method stub
//		super.init(config);
//		System.out.println("init(): Loading products");
//		
//		products = new HashMap<>();
//		
////		products.add("Laptop");
////		products.add("Mobile Phones");
////		products.add("Headphones");
////		products.add("Keyboard");
////		
//		cart=new HashMap<>();
//		
//		String allproducts = config.getInitParameter("Products");
//		String allpro[] = allproducts.split(",");
//		
//		for(String p:allpro) {
//			String[] v=p.split("=");
//			String product = v[0].trim();
//			int price = Integer.parseInt(v[1].trim());
//			products.put(product,price);
//		}
//		
//		
//	}
//	
//	protected void service(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException{
//		System.out.println("service(): Request received");
//		super.service(req, res);
//	}
//
//	/**
//	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
//	 */
//	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
//		// TODO Auto-generated method stub
//		res.setContentType("text/html");
//		PrintWriter out=res.getWriter();
//		
//		out.println("<h2> Available Products </h2>");
//
//		for (Map.Entry<String, Integer> entry : products.entrySet()) {
//		    out.println(entry.getKey() + "\t = \t" + entry.getValue()+"\n");
//		    out.println();
//		}
//
//		int total=0;
//		out.println("<h2>Your Cart</h2>");
//		if(cart.isEmpty()) {
//			out.println("Cart is empty.");
//		}else {
//			
//			for (Map.Entry<String, Integer> entry : cart.entrySet()) {
//			    out.println(entry.getKey() + "\t = \t" + entry.getValue()+"\n");
//			    total+=entry.getValue();
//			}
//
//		}
//		
//
//		req.getSession().setAttribute("finalTotal", total);
//
//        // Redirect to final bill page
////        res.sendRedirect("logout.html");
//
//		
//		out.println("<br> <a href='Shopping.html'>Back to Shop </a>");
//		
////		res.getWriter().append("Served at: ").append(request.getContextPath());
//	}
//
//	/**
//	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
//	 */
//	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
//		// TODO Auto-generated method stub
//		
//		String item=req.getParameter("item");
//		
//		if(item!=null && products.containsKey(item)) {
//			int price = products.get(item);
//			cart.put(item,price);
//		}
//		res.sendRedirect("shop");
//		
//	}
//	
//	public void destroy() {
//		System.out.println("destroy(): Clearing data");
//		products.clear();
//	}
//
//}


package Assignment2;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
* Servlet implementation class productsPrice
*/
@WebServlet("/ShoppingCart") 	 
public class ShoppingCart extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ArrayList<String> products;
	ArrayList<String> cart;
	Map<String, Integer> product;
	public void init() throws ServletException {
		System.out.println("init(): Loading products");
		products = new ArrayList<>();
		products.add("Pencil");
		products.add("book");
		products.add("rubber");
		products.add("paper");
		product = new LinkedHashMap<>();
		product.put("pencil", 10);
		product.put("book", 200);
		product.put("rubber", 5);
		product.put("paper", 20);
		cart = new ArrayList<>();
	}
	protected void service(HttpServletRequest req, HttpServletResponse res)
	throws ServletException, IOException {
		System.out.println("service(): Request received");
		super.service(req, res);
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<h2>Available Products</h1>");
		for (String p : products) {
			out.println(p + "<br>");
		}
		out.println("<h2>Your Cart</h2>");
		if (cart.isEmpty()) {
			out.println("Cart is empty");
		} else {
			for (String c : cart) {
				out.println(c + "<br>");
			}
		}
		out.println("<br><a href = 'Shopping.html'>Back to Shop</a> ");
	}
	public void destroy() {
		System.out.println("destroy(): Clearing data");
		products.clear();
		cart.clear();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String item = request.getParameter("item");
		String action = request.getParameter("action");
		
		if ("Add to Cart".equals(action)) {
			if (item != null) {
				item = item.trim().toLowerCase();
				if (product.containsKey(item)) {
					cart.add(item);
				}
			}
			response.sendRedirect("ShoppingCart");
			return;
		}
		
		if ("Logout".equals(action)) {
			int total = 0;
			for (String c : cart) {
				Integer price = product.get(c);
				if (price != null) total += price;
			}
			request.setAttribute("total", total);
			request.setAttribute("items", new ArrayList<>(cart));
			cart.clear();
			RequestDispatcher rd = request.getRequestDispatcher("/ShoppingCart");
			rd.forward(request, response);
			return;
			
		}
		
		response.sendRedirect("ShoppingCart");
	}

}