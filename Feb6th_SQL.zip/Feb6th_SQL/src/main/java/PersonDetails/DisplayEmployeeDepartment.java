package PersonDetails;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

public class DisplayEmployeeDepartment {
	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx=null;
		try {
			tx=(Transaction) session.beginTransaction();
			
			Query<Employee> query = session.createNamedQuery("Employee.findAll", Employee.class);
			
			List<Employee> list = query.list();
			
			for(Employee p:list) {
				System.out.println("Employee ID: "+p.getId());
				System.out.println("Name : "+p.getName());
				Department ps=p.getDepartment();
				
				if(ps != null) {
					System.out.println("Department : "+ps.getName());
				}
				
				System.out.println("---------------");
			}
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}finally {
			session.close();
		}
		
	}
}
