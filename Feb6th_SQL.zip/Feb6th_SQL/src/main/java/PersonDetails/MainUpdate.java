package PersonDetails;

import org.hibernate.Session;
import org.hibernate.Transaction;
public class MainUpdate {
	public static void main(String[] args) {
		Session session=HibernateUtil.getSessionFactory().openSession();
		Transaction tx=null;
		try {
			tx = (Transaction)session.beginTransaction();
			Person p=session.get(Person.class, 7);//existing ID
			
			if(p!=null) {
				p.setName("Nandhini");
				Passport ps = p.getPassport();
				ps.setNumber("IND2720");
				
				System.out.println("Record updated successfully!");
			}else {
				System.out.println("Records not found!");
			}
			tx.commit();
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}finally {
			session.close();
		}
	}
}
