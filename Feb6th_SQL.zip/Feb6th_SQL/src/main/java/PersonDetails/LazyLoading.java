package PersonDetails;

import org.hibernate.Transaction;

import java.util.ArrayList;

import org.hibernate.Session;

public class LazyLoading {
	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx=session.beginTransaction();
		
		Department d1=new Department();
		d1.setName("IT");
		
		Department d2=new Department();
		d2.setName("ECE");
		
		Employee e1 = new Employee();
		e1.setName("Suresh");
		e1.setDepartment(d1);
		
		Employee e2 = new Employee();
		e2.setName("Ravi");
		e2.setDepartment(d1);
		
		ArrayList<Employee> empList1 = new ArrayList<>();
		empList1.add(e1);
		empList1.add(e2);
		d1.setEmployees(empList1);
		
		Employee e3 = new Employee();
		e3.setName("Raji");
		e3.setDepartment(d2);
		
		Employee e4=new Employee();
		e4.setName("Nandhini");
		e4.setDepartment(d2);
		
		
		
		ArrayList<Employee> empList2 = new ArrayList<>();
		empList2.add(e3);
		empList2.add(e4);
		d2.setEmployees(empList2);
		
		session.save(d1);
		session.save(d2);
		tx.commit();
		session.close();
	}
}