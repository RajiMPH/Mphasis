package PersonDetails;


import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.List;

import org.hibernate.Session;

public class MainDisplay {
	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx=null;
		try {
			tx=(Transaction) session.beginTransaction();
			
			Query<Person> query = session.createQuery("from Person", Person.class);
			
			List<Person> list = query.list();
			
			for(Person p:list) {
				System.out.println("Person ID: "+p.getPid());
				System.out.println("Name : "+p.getName());
				Passport ps=p.getPassport();
				
				if(ps != null) {
					System.out.println("Passport : "+ps.getNumber());
				}
				
				System.out.println("---------------");
			}
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}finally {
			session.close();
		}
		
	}
	
}
