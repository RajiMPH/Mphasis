package PersonDetails;

import org.hibernate.Transaction;

import org.hibernate.Session;

public class main1 {
	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx=null;
		try {
			tx = (Transaction) session.beginTransaction();
			Person p=new Person();
			p.setName("Raji");
			
			Passport ps = new Passport();
			ps.setNumber("IND2708");
			
			p.setPassport(ps);
			
			session.save(p);
			
			tx.commit();
			System.out.println("Record saved successfully!");
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}finally {
			session.close();
		}
				
	}
}
