package PersonDetails;

import org.hibernate.Transaction;

import org.hibernate.Session;

public class MainDelete {
	
	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		
		try {
			tx=(Transaction) session.beginTransaction();
			Person p =session.get(Person.class, 1);
			if(p!=null) {
				session.delete(p);
				System.out.println("Record deleted successfully");
			}else {
				System.out.println("Record not found");
			}
			tx.commit();
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}finally {
			session.close();
		}
	}

}
