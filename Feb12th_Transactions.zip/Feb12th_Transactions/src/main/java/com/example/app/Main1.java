package com.example.app;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.example.config.AppConfig;
import com.example.repository.AccountRepository;
import com.example.service.BankService;

public class Main1 {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		BankService service = context.getBean(BankService.class);
		AccountRepository repo = context.getBean(AccountRepository.class);
		
		try {
			service.transfer(1,2,1000);
		}catch(Exception e) {
			System.out.println("Exception: "+e.getMessage());
		}
		
		System.out.println("Balance of 1: "+repo.getBalance(1));
		System.out.println("Balance of 2: "+repo.getBalance(2));
		context.close();
	}

}
