package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.repository.AccountRepository;

@Service
public class BankService {
	@Autowired
	private AccountRepository repo;
	
	@Transactional 
	public void transfer(int fromId,int toId, double amount) {
		repo.debit(fromId,amount);
		
		//simulating failure - because of @transactional, the process stops and redo the operations done 
									//previously for consistency in data
//		if(true) {
//			throw new RuntimeException("Transaction Failed!");
//		}
		
		repo.credit(toId,amount);
	}

}
