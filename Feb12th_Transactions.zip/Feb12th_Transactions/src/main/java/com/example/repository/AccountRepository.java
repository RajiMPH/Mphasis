package com.example.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class AccountRepository {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public void debit(int id, double amount) {
		jdbcTemplate.update("UPDATE account SET balance = balance - ? WHERE id =?", amount,id);
	}
	
	public void credit(int id,double amount) {
		jdbcTemplate.update("UPDATE account SET balance = balance + ? WHERE id=?",amount,id);
	}
	
	public double getBalance(int id) {
		return jdbcTemplate.queryForObject("SELECT balance FROM account WHERE id=?", Double.class,id);
	}
	
	
}
