package Assignment;

import StudentDetails.Student;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/students")
public class StudentServlet extends HttpServlet {

    private static List<Student> students = new ArrayList<>();

    // READ + DELETE + SHOW EDIT FORM
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws IOException {

        String editId = req.getParameter("editId");
        String deleteId = req.getParameter("deleteId");

        // DELETE
        if (deleteId != null) {
            int id = Integer.parseInt(deleteId);
            students.removeIf(s -> s.getId() == id);
            res.sendRedirect("students");
            return;
        }

        res.setContentType("text/html");
        PrintWriter out = res.getWriter();

        // EDIT FORM
        if (editId != null) {
            int id = Integer.parseInt(editId);
            Student student = students.stream()
                    .filter(s -> s.getId() == id)
                    .findFirst()
                    .orElse(null);

            out.println("<html><body>");
            out.println("<h2>Edit Student</h2>");

            out.println("<form action='students' method='post'>");
            out.println("<input type='hidden' name='action' value='update'>");
            out.println("<input type='hidden' name='id' value='" + student.getId() + "'>");

            out.println("Name: <input type='text' name='name' value='" +
                    student.getName() + "'><br><br>");
            out.println("Course: <input type='text' name='course' value='" +
                    student.getCourse() + "'><br><br>");

            out.println("<input type='submit' value='Update Student'>");
            out.println("</form>");

            out.println("<br><a href='students'>Back</a>");
            out.println("</body></html>");
            return;
        }

        // STUDENT LIST
        out.println("<html><body>");
        out.println("<h2>Student List</h2>");
        out.println("<table border='1'>");
        out.println("<tr><th>ID</th><th>Name</th><th>Course</th><th>Action</th></tr>");

        for (Student s : students) {
            out.println("<tr>");
            out.println("<td>" + s.getId() + "</td>");
            out.println("<td>" + s.getName() + "</td>");
            out.println("<td>" + s.getCourse() + "</td>");
            out.println("<td>");
            out.println("<a href='students?editId=" + s.getId() + "'>Edit</a> | ");
            out.println("<a href='students?deleteId=" + s.getId() + "'>Delete</a>");
            out.println("</td>");
            out.println("</tr>");
        }

        out.println("</table>");
        out.println("<br><a href='index.html'>Add New Student</a>");
        out.println("</body></html>");
    }

    // CREATE + UPDATE
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws IOException {

        String action = req.getParameter("action");

        // UPDATE
        if ("update".equals(action)) {
            int id = Integer.parseInt(req.getParameter("id"));
            String name = req.getParameter("name");
            String course = req.getParameter("course");

            for (Student s : students) {
                if (s.getId() == id) {
                    s.setName(name);
                    s.setCourse(course);
                    break;
                }
            }
            res.sendRedirect("students");
            return;
        }

        // CREATE
        int id = Integer.parseInt(req.getParameter("id"));
        String name = req.getParameter("name");
        String course = req.getParameter("course");

        students.add(new Student(id, name, course));
        res.sendRedirect("students");
    }
}