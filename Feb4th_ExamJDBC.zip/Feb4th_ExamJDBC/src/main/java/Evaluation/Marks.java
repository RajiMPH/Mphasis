package Evaluation;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Questions.Question;

/**
 * Servlet implementation class Marks
 */
@WebServlet("/Marks")
public class Marks extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Marks() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		doGet(request, response);
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession(false);
		ArrayList<Question> QuestionList= (ArrayList<Question>)session.getAttribute("QuestionList");
		
		int marks = 0;
		Map<Integer,String> ans = (Map<Integer,String>)session.getAttribute("Result");
		

		for (Question q : QuestionList) {
                String userAns = request.getParameter("ans_" + q.getQId()); // may be null
                String correct  = q.getAns();                               // may be null
                if (userAns != null && correct != null && correct.equalsIgnoreCase(userAns)) {
                    marks++;
                }
        }

		String idst = (String)session.getAttribute("SId");
		int id=Integer.parseInt(idst);
		String user = request.getParameter("user");
		
		out.println("<h3>" + user + "!, you got " + marks + " marks");
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			// 2. Create Connection
			Connection con = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/mphasis",
				"root",
				"root@39"
			);
			String sql = "INSERT INTO STUDENTS(SId,Name,Marks) VALUES (?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			ps.setString(2, user);
			ps.setInt(3,marks);
			
			int i=ps.executeUpdate();
			
			if(i>0) {
				out.println("<h3>Query Executed Successfully</h3>");
			}
			else {
				out.println("<h3>Zero Records affected</h3>");
			}
			
			ps.close();
			con.close();
			
		}catch(Exception e){
			out.println("Error: " + e.getMessage());
		}
		
	}

}
