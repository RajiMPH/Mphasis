package Questions;

public class Question {
	int QId;
	String QA;
	String OP1;
	String OP2;
	String Ans;
	
	public Question(int id,String question,String op1,String op2,String answer) {
		this.QId = id;
		this.QA = question;
		this.OP1 = op1;
		this.OP2 = op2;
		this.Ans = answer;
		
	}
	public int getQId() {
		return QId;
	}
	public void setQId(int qId) {
		QId = qId;
	}
	public String getQA() {
		return QA;
	}
	public void setQA(String qA) {
		QA = qA;
	}
	public String getOP1() {
		return OP1;
	}
	public void setOP1(String oP1) {
		OP1 = oP1;
	}
	public String getOP2() {
		return OP2;
	}
	public void setOP2(String oP2) {
		OP2 = oP2;
	}
	public String getAns() {
		return Ans;
	}
	public void setAns(String ans) {
		Ans = ans;
	}
	
}
