package Controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;

@Controller
public class HelloController {
	
	@RequestMapping("/hello")
	public String hello() {
		return "index";
	}
	
	
	 @RequestMapping("/home") 
	 public String showform() {
		 System.out.println("I am contact");
		 return "contact";
	 }
	 
	
	@RequestMapping(value="/processform", method=RequestMethod.POST)
	public String HandleForm(@RequestParam("a") String x,
			@RequestParam("b") String y,
			@RequestParam("c") String z,Model object1) {
		
		object1.addAttribute("username",x);
		object1.addAttribute("email",y);
		object1.addAttribute("mobile",z);
		return "success";
	}
	
	@RequestMapping("/hi")
	public String hello(Model model) {
		model.addAttribute("msg","Welcome to spring MVC");
		model.addAttribute("name","Raji");
		return "hello";
	}
	@RequestMapping("/student")
	public String student(Model model) {
		Student s = new Student();
		s.setId(101);
		s.setName("Rajii");
		model.addAttribute("student",s);
		return "student";
	}
	
	@RequestMapping("/raji")//sending list
	public String courses(Model model) {
		List<String> list=List.of("Spring","Hibernate","Microservices","Java","C++");
		model.addAttribute("courses",list);
		return "courses";
	}
	
	//model and view
	@RequestMapping("/sam")
	public ModelAndView home() {
		ModelAndView ob=new ModelAndView();
		
		ob.addObject("name","Raji");
		ob.addObject("mobile",2708);
		ob.addObject("address","chennai");
		System.out.println("This is home URL");
		
		ob.setViewName("first");
		return ob;
	}
	
	@RequestMapping("/nandhini")
	public ModelAndView home1(){
		ModelAndView ob=new ModelAndView();
		
		ob.addObject("name","Nandhini");
		ob.addObject("mobile",2222);
		System.out.println("this is home url");
		
		List<Integer> list = new ArrayList<Integer>();
		list.add(111);
		list.add(278);
		list.add(0305);
		list.add(350);
		ob.addObject("mylist",list);
		ob.setViewName("second");
		return ob;
	}
}
