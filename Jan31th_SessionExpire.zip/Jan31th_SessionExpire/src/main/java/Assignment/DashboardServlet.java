package Assignment;

import java.io.IOException;
import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import javax.servlet.http.*;

public class DashboardServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false); // do NOT create new session

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        if (session == null || session.getAttribute("user") == null) {
            out.println("<h1>Session expired! Please login again.</h1>");
            out.println("<a href='Login.html'>Login</a>");
        } else {
            String user = (String) session.getAttribute("user");
            out.println("<h1>Welcome to Dashboard</h1>");
            out.println("Hello " + user + "<br><br>");
            out.println("<a href='logout'>Logout</a>");
        }
    }
}