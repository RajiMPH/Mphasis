package Assignment;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");

        HttpSession session = request.getSession();
        session.setAttribute("user", username);

        // Session timeout in seconds (1 minute)
        session.setMaxInactiveInterval(60);

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<h2>Welcome " + username + "</h2>");
        out.println("<a href='dashboard'>Go to Dashboard</a>");
    }
}