package com.example.aspect;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

import com.example.security.UserStore;

@Aspect
public class LoginAspect {
	
	@Before("execution(* com.example.service.*.*(..))")
	public void checkLogin(JoinPoint joinPoint) {
		Object[] args=joinPoint.getArgs();
		String username=(String) args[0];
		
		if(!UserStore.USERS.contains(username)) {
			throw new RuntimeException("X Login failed! User not autorized!...");
		}
		System.out.println("Login successful for user: "+username);
	}

}
