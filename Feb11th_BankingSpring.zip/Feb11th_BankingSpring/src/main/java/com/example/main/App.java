package com.example.main;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.service.BankService;

public class App {
	public static void main(String[] args) {
		ApplicationContext ctx= new ClassPathXmlApplicationContext("com/example/main/con1.xml");
		
		BankService service=ctx.getBean(BankService.class);
		
		try{
			service.transferMoney("Kamali");
			service.transferMoney("Ilakkiya");
		}catch(Exception e){
			
			System.out.println(e.getMessage());
		}
	}

}
