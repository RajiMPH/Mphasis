package com.example.service;

public class BankService {
	public void transferMoney(String username) {
		System.out.println("Money transferred successfully for user: "+username);
	}

}
