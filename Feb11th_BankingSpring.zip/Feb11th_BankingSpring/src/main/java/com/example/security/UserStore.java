package com.example.security;
import java.util.ArrayList;
import java.util.List;
public class UserStore {
	public static final List<String> USERS = new ArrayList<>();
	static {
		USERS.add("Raji");
		USERS.add("Nandhini");
		USERS.add("Sathya");
	}

}
